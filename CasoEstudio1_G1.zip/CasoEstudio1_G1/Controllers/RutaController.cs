﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasoEstudio1_G1_API.Controllers
{
    public class RutaController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RutaController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Listar todas las rutas
        public IActionResult Index()
        {
            var rutas = _context.Rutas.ToList();
            return View(rutas);
        }

        // Vista para Crear una nueva ruta
        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        // Guardar una nueva ruta en la BD
        [HttpPost]
        public IActionResult Crear(Ruta nombreRuta)
        {
            if (ModelState.IsValid)
            {
                _context.Rutas.Add(nombreRuta);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ruta);
        }

        // Vista para Editar una ruta existente
        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if (id == null || id == 0)
            {
                ViewData["Tipo"] = 1;
                return View();
            }
            else
            {
                var ruta = _context.Rutas.Find(id);
                if (ruta == null)
                {
                    ViewData["Tipo"] = 2;
                    return View();
                }
                else
                {
                    ViewData["Tipo"] = 3;
                    return View(ruta);
                }
            }
        }

        // Guardar los cambios de una ruta editada
        [HttpPost]
        public IActionResult Editar(Ruta ruta)
        {
            if (ModelState.IsValid)
            {
                _context.Rutas.Update(ruta);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ruta);
        }

        // Vista para eliminar una ruta
        [HttpGet]
        public IActionResult Eliminar(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var ruta = _context.Rutas.Find(id);
            if (ruta == null)
            {
                return NotFound();
            }

            return View(ruta);
        }

        // Confirmar la eliminación de una ruta
        [HttpPost, ActionName("Eliminar")]
        public IActionResult EliminarConfirmado(int id)
        {
            var ruta = _context.Rutas.Find(id);
            if (ruta == null)
            {
                return NotFound();
            }

            _context.Rutas.Remove(ruta);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
