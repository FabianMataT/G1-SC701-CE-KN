﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CasoEstudio1_G1_API.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UsuarioController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Listar todos los usuarios
        public IActionResult Index()
        {
            var usuarios = _context.Usuarios.Include(u => u.Rol).ToList();
            return View(usuarios);
        }

        // Vista para Crear un nuevo usuario
        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        // Guardar un nuevo usuario en la BD
        [HttpPost]
        public IActionResult Crear(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _context.Usuarios.Add(usuario);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(usuario);
        }

        // Vista para Editar un usuario existente
        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if (id == null || id == 0)
            {
                ViewData["Tipo"] = 1;
                return View();
            }
            else
            {
                var usuario = _context.Usuarios.Find(id);
                if (usuario == null)
                {
                    ViewData["Tipo"] = 2;
                    return View();
                }
                else
                {
                    ViewData["Tipo"] = 3;
                    return View(usuario);
                }
            }
        }

        // Guardar los cambios de un usuario editado
        [HttpPost]
        public IActionResult Editar(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _context.Usuarios.Update(usuario);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(usuario);
        }

        // Vista para eliminar un usuario
        [HttpGet]
        public IActionResult Eliminar(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var usuario = _context.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        // Confirmar la eliminación de un usuario
        [HttpPost, ActionName("Eliminar")]
        public IActionResult EliminarConfirmado(int id)
        {
            var usuario = _context.Usuarios.Find(id);
            if (usuario == null)
            {
                return NotFound();
            }

            _context.Usuarios.Remove(usuario);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
